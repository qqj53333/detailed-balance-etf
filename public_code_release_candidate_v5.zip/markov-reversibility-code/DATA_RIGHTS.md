# Third-party data rights

This release contains no raw/normalized quotes, realized daily returns or daily
forecast rows. Data hashes are identifiers, not a substitute data feed.

Checked 15 November 2026:

- yfinance states that its library license is separate from rights to downloaded
  data and refers users to Yahoo's terms; its README describes the API as intended
  for personal use: https://github.com/ranaroussi/yfinance
- Yahoo Terms of Service:
  https://legal.yahoo.com/us/en/yahoo/terms/otos/index.html
  Official search-index text was accessible, but direct retrieval returned 999.
- Yahoo Finance exchanges/data providers:
  https://help.yahoo.com/kb/SLN2310.html
  Direct retrieval returned 429 during this review.

The complete applicable Yahoo/provider terms and permissions for this user's
jurisdiction and publication have not been established. No claim of legal
clearance is made. The software package alone grants no permission to obtain,
redistribute or publicly deposit those snapshots. Confirm rights with the relevant
provider before sharing data; authorized reviewer access must also respect terms.

The public-code allowlist deliberately excludes all market-data files, aggregate
result dumps, figures and manuscripts. Those are handled separately in the paper
package and are not represented as licensed third-party datasets.
