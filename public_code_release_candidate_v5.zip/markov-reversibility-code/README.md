# Detailed balance in three-state ETF forecasting

Data-free replication code for a fixed comparison of IID, unrestricted and
reversible Markov forecasts and intraday long/cash allocation.

## Installation and offline checks

The original Windows x64 environment used Python 3.12.6.

    python -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install -r requirements-lock.txt
    python -m pip install --no-deps -e .
    python verify_release.py
    python -m unittest discover -s tests -v

The tests generate synthetic observations only. No downloaded prices or daily
price-derived sequences are distributed.

## Reproduce using authorized local data

Obtain permission to use suitable data independently. Supply Date, Open and Close
with consistent adjustment, covering each recorded history. To reproduce the
archived snapshot exactly, its normalized CSV SHA-256 must match the fingerprint.

    python replay.py --ticker SPY --input-csv private/SPY.csv --output results/SPY

Repeat for QQQ and IWM. The wrapper verifies model hashes and input identity,
audits session coverage, then runs the frozen final experiment and bootstrap.
It does not download data. The retained package contains the original vendor
adapter for transparency, but its software license does not authorize data
access. Review applicable terms before invoking any download function.

If you cannot lawfully obtain the exact snapshot, code and synthetic tests remain
usable, but exact numerical reproduction has not been achieved. Do not substitute
new data silently. A fresh vendor download may have revised historical values.

## Evidence boundaries

Source hashes are checked against the original internal study manifest.
Data hashes identify retained snapshots without distributing them. Hashes do not
prove external preregistration, data rights, market-data accuracy or economic
validity. No DOI or live repository location is asserted in this package.

## Licensing

No open-source redistribution license has yet been selected by the author for
this release candidate. Third-party dependencies retain their own licenses.
Select the intended code license before a public release; no market-data license
is granted by this package.
