# Protocol v1.1 public description

The internally frozen experiment compares IID destination probabilities, an
unrestricted three-state Markov chain and a reversible chain satisfying detailed
balance, with alpha = 1 smoothing. Training-only expanding terciles classify
same-session adjusted Open-to-Close returns. Minimum history: 2,520 sessions.

Signals after close t enter at open t+1 and liquidate at close t+1. Exposure is
clip(0.5 + 0.5 * (p_upper - p_lower), 0, 1). Turnover is twice exposure. Cash earns
zero; leverage and shorting are excluded. Linear starting-notional costs are
5 bps per side primary, with 1, 10 and 25 bps sensitivities.

Development ends 2009-12-31, validation ends 2014-12-31, final targets run from
2015-01-02 to 2025-12-31 (2,766 sessions per ETF). SPY is primary; QQQ and IWM
apply identical settings to each available history. Later fits may use earlier
realized final-period outcomes but fixed specifications cannot be selected on them.

Report log loss, sum-form Brier, ten-bin classwise calibration, compounded net
return, conventional sqrt(252) Sharpe with zero risk-free return, maximum
drawdown including initial capital, turnover and costs. Paired non-circular
moving blocks: 5,000 draws, seed 20261113, primary length 20, sensitivities 10/60.
Contrasts: reversible minus unrestricted and unrestricted minus IID.
Intervals condition on saved forecasts, do not refit, and are not multiplicity
adjusted. Undefined Sharpe intervals are suppressed.

The original internal approval record and its hash are retained separately.
This public description is an editorial restatement prepared after the experiment,
not an externally preregistered document. The final period has been inspected.
