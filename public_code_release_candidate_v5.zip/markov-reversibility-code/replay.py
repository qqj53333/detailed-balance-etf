"""Replay frozen study on an independently authorized, hash-matched snapshot."""
from pathlib import Path
import argparse, hashlib, json, subprocess, sys
import exchange_calendars as xc
from markov_research.data import load_input_csv
from markov_research.audit import audit_prices
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument("--ticker",choices=["SPY","QQQ","IWM"],required=True)
p.add_argument("--input-csv",type=Path,required=True)
p.add_argument("--output",type=Path,required=True)
a=p.parse_args()
subprocess.run([sys.executable,str(root/"verify_release.py")],check=True)
record=json.loads((root/"frozen_fingerprints.json").read_text())["data"][a.ticker]
assert hashlib.sha256(a.input_csv.read_bytes()).hexdigest()==record["normalized_sha256"], "Snapshot differs; no frozen-result reproduction claimed."
prices=load_input_csv(a.input_csv)
cal=xc.get_calendar("XNYS",start="1993-01-01",end="2026-01-31")
coverage=audit_prices(prices,cal.sessions_in_range(record["first_date"],record["last_date"]))
assert coverage["passed_session_coverage"], coverage
before=set(a.output.glob("run_*")) if a.output.exists() else set()
subprocess.run([sys.executable,"-m","markov_research.cli","--ticker",a.ticker,
    "--input-csv",str(a.input_csv),"--phase","final","--output",str(a.output)],check=True)
new=set(a.output.glob("run_*"))-before
assert len(new)==1
run=new.pop()
subprocess.run([sys.executable,"-m","markov_research.inference",
    "--forecasts",str(run/"forecasts.csv"),"--split","final_test"],check=True)
print(run)
