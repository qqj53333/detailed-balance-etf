"""Reproducible Markov reversibility research scaffold."""

__version__ = "0.1.0"
