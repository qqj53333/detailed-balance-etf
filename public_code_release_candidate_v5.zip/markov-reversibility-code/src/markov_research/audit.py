"""Audit a price snapshot against an explicitly bounded session calendar."""
import argparse
from datetime import datetime, timezone
import json
from importlib.metadata import version
from pathlib import Path

import pandas as pd

from .data import load_input_csv, sha256_file


def audit_prices(prices: pd.DataFrame, expected_sessions: pd.DatetimeIndex) -> dict:
    """Check full requested coverage, including missing leading/trailing dates."""
    observed = pd.DatetimeIndex(prices.index).tz_localize(None).normalize()
    expected = pd.DatetimeIndex(expected_sessions).tz_localize(None).normalize()
    if expected.empty or expected.duplicated().any() or not expected.is_monotonic_increasing:
        raise ValueError("Expected sessions must be nonempty, unique, and ordered.")
    missing = expected.difference(observed)
    unexpected = observed.difference(expected)
    duplicate = observed[observed.duplicated()].unique()
    returns = prices["Close"] / prices["Open"] - 1
    largest = returns.abs().nlargest(min(5, len(returns))).index
    dates = lambda x: [d.strftime("%Y-%m-%d") for d in x]
    return {
        "passed_session_coverage": not (len(missing) or len(unexpected) or len(duplicate)),
        "expected_sessions": len(expected), "observed_rows": len(observed),
        "expected_first": str(expected.min().date()),
        "expected_last": str(expected.max().date()),
        "missing_sessions": dates(missing), "unexpected_sessions": dates(unexpected),
        "duplicate_sessions": dates(duplicate),
        "largest_absolute_intraday_returns_for_review": [
            {"date": str(day.date()), "return": float(returns.loc[day])}
            for day in largest] if not len(duplicate) else [],
        "scope": "Calendar coverage only; does not certify price accuracy or executable fills.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prices", required=True)
    parser.add_argument("--start", required=True, help="Declared start, inclusive.")
    parser.add_argument("--end", required=True, help="Declared end, inclusive.")
    parser.add_argument("--calendar", default="XNYS",
                        help="Reference US equity session calendar, not a listing assertion.")
    args = parser.parse_args()
    import exchange_calendars as xcals
    calendar = xcals.get_calendar(args.calendar, start=args.start, end=args.end)
    expected = calendar.sessions_in_range(args.start, args.end)
    source = Path(args.prices)
    report = audit_prices(load_input_csv(source), expected)
    report.update({"source_file": source.name, "source_sha256": sha256_file(source),
                   "reference_calendar": args.calendar,
                   "calendar_package_version": version("exchange-calendars"),
                   "requested_start": args.start, "requested_end": args.end})
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = source.parent / f"calendar_audit_{stamp}.json"
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"report": str(output.resolve()), **report}, indent=2))
    if not report["passed_session_coverage"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
