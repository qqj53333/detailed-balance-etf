"""Command-line entry point for the reproducible experiment."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone, date, timedelta
from pathlib import Path
from typing import Any

from . import __version__
from .data import fetch_yahoo, load_input_csv, sha256_file, software_versions
from .experiment import build_metrics, run_walkforward


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the three-state Markov reversibility walk-forward study."
    )
    parser.add_argument("--ticker", default="SPY", help="ETF ticker; SPY is the primary asset.")
    parser.add_argument("--start", default="1993-01-29", help="Inclusive vendor start date.")
    parser.add_argument(
        "--end",
        default="2026-01-01",
        help="Exclusive vendor end date; default preserves the 2025 final-test cutoff.",
    )
    parser.add_argument("--input-csv", help="Use a local Date, Open, Close CSV instead of downloading.")
    parser.add_argument("--output", default="results/SPY", help="Directory for run artifacts.")
    parser.add_argument("--min-train", type=int, default=2520, help="Expanding-history warm-up.")
    parser.add_argument("--alpha", type=float, default=1.0, help="Fixed add-alpha smoothing.")
    parser.add_argument(
        "--cost-bps",
        type=float,
        nargs="+",
        default=[1.0, 5.0, 10.0, 25.0],
        help="One-way cost sensitivities in basis points.",
    )
    parser.add_argument("--development-end", default="2009-12-31")
    parser.add_argument("--validation-end", default="2014-12-31")
    parser.add_argument("--final-end", default="2025-12-31")
    parser.add_argument("--phase", choices=["development", "validation", "final"],
                        default="validation", help="Limit evaluated data to this phase.")
    return parser


def _local_data_provenance(input_csv: str, prices: Any, output_dir: Path) -> dict[str, Any]:
    source_path = Path(input_csv).expanduser().resolve()
    normalized_path = output_dir / "normalized_prices.csv"
    prices.to_csv(normalized_path, date_format="%Y-%m-%d")
    return {
        "source": "user-supplied CSV",
        "input_file_name": source_path.name,
        "input_sha256": sha256_file(source_path),
        "normalized_file": normalized_path.name,
        "normalized_sha256": sha256_file(normalized_path),
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "row_count": int(len(prices)),
        "first_date": prices.index.min().strftime("%Y-%m-%d"),
        "last_date": prices.index.max().strftime("%Y-%m-%d"),
        "software_versions": software_versions(),
    }


def main() -> None:
    args = _parser().parse_args()
    phase_end = {"development": args.development_end,
                 "validation": args.validation_end, "final": args.final_end}[args.phase]
    download_end = min(date.fromisoformat(args.end),
                       date.fromisoformat(phase_end) + timedelta(days=1)).isoformat()
    output_root = Path(args.output).expanduser()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output_dir = output_root / f"run_{run_id}"
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.input_csv:
        prices = load_input_csv(args.input_csv)
        data_provenance = _local_data_provenance(args.input_csv, prices, output_dir)
    else:
        prices, data_provenance = fetch_yahoo(
            ticker=args.ticker,
            start=args.start,
            end=download_end,
            output_dir=output_dir,
        )

    # Slice before fitting, scoring, or writing analysis data for this phase.
    prices = prices.loc[:phase_end]
    if prices.empty:
        raise ValueError("No observations in the selected phase.")
    prices.to_csv(output_dir / "analysis_prices.csv", date_format="%Y-%m-%d")
    with (output_dir / "provenance.json").open("w", encoding="utf-8") as handle:
        json.dump(data_provenance, handle, indent=2)
    forecasts = run_walkforward(
        prices=prices,
        ticker=args.ticker.upper(),
        min_train_observations=args.min_train,
        alpha=args.alpha,
        development_end=args.development_end,
        validation_end=args.validation_end,
        final_end=args.final_end,
    )
    for model in ("iid", "markov", "reversible"):
        for bps in args.cost_bps:
            suffix = f"{model}_{bps:g}bps"
            forecasts[f"cost_{suffix}"] = forecasts[f"turnover_{model}"] * bps / 10000
            forecasts[f"net_return_{suffix}"] = (
                forecasts[f"gross_return_{model}"] - forecasts[f"cost_{suffix}"])
    forecasts_path = output_dir / "forecasts.csv"
    forecasts.to_csv(forecasts_path, index=False)
    metrics, calibration = build_metrics(
        forecasts,
        cost_bps=tuple(args.cost_bps),
    )
    calibration_path = output_dir / "calibration.csv"
    calibration.to_csv(calibration_path, index=False)

    summary = {
        "project": "Markov Reversibility and Financial Forecasting",
        "software_version": __version__,
        "run_id": run_id,
        "phase": args.phase,
        "analysis_data_sha256": sha256_file(output_dir / "analysis_prices.csv"),
        "run_at_utc": datetime.now(timezone.utc).isoformat(),
        "ticker": args.ticker.upper(),
        "data": data_provenance,
        "protocol": {
            "state_definition": "adjusted same-session Open-to-Close return",
            "decision_timing": "forecast after close; enter next open; exit target close",
            "states": ["Down", "Neutral", "Up"],
            "thresholds": "expanding-history training-only empirical terciles",
            "minimum_training_observations": args.min_train,
            "smoothing_alpha": args.alpha,
            "development_end": args.development_end,
            "validation_target_sessions": [
                (date.fromisoformat(args.development_end) + timedelta(days=1)).isoformat(),
                args.validation_end,
            ],
            "final_test_target_sessions": [
                (date.fromisoformat(args.validation_end) + timedelta(days=1)).isoformat(),
                args.final_end,
            ],
            "cost_bps_per_side": list(args.cost_bps),
            "allocation": "clip(0.5 + 0.5 * (p_up - p_down), 0, 1)",
            "walk_forward": "expanding history; no random shuffle",
        },
        **metrics,
        "artifacts": {
            "forecasts_csv": forecasts_path.name,
            "forecasts_sha256": sha256_file(forecasts_path),
            "calibration_csv": calibration_path.name,
            "software_versions": software_versions(),
        },
        "interpretation_note": (
            "These are historical simulations, not guarantees of future results. "
            "Forecast metrics and portfolio metrics are separate."
        ),
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, allow_nan=False)

    print(f"Saved {len(forecasts)} forecasts to {output_dir.resolve()}")
    print("Read summary.json for separated forecast and portfolio metrics.")


if __name__ == "__main__":
    main()
