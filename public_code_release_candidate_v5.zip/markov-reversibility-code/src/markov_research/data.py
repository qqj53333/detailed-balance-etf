"""Price-data loading and provenance helpers."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _flatten_yfinance_columns(frame: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(frame.columns, pd.MultiIndex):
        return frame
    flattened: dict[str, pd.Series] = {}
    for field in ("Open", "Close"):
        matches = [
            column
            for column in frame.columns
            if any(str(level).casefold() == field.casefold() for level in column)
        ]
        if len(matches) != 1:
            raise ValueError(f"Expected exactly one {field} field for one ticker.")
        flattened[field] = frame[matches[0]]
    return pd.DataFrame(flattened, index=frame.index)


def normalize_prices(frame: pd.DataFrame) -> pd.DataFrame:
    """Return a clean Date-indexed table with positive Open and Close prices."""
    data = _flatten_yfinance_columns(frame.copy())
    date_column = next(
        (column for column in data.columns if str(column).casefold() == "date"),
        None,
    )
    if date_column is not None:
        data = data.set_index(date_column)
    elif not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("Supply a Date column or a DatetimeIndex.")
    lookup = {str(column).casefold(): column for column in data.columns}
    missing = [name for name in ("open", "close") if name not in lookup]
    if missing:
        raise ValueError(f"Price data is missing required columns: {', '.join(missing)}")
    data = data.rename(
        columns={lookup["open"]: "Open", lookup["close"]: "Close"}
    )[["Open", "Close"]]
    data.index = pd.to_datetime(data.index, errors="coerce").tz_localize(None)
    data.index.name = "Date"
    if data.index.isna().any() or data.index.duplicated().any():
        raise ValueError("Invalid or duplicate dates require explicit data review.")
    data = data.sort_index().apply(pd.to_numeric, errors="coerce")
    if not np.isfinite(data.to_numpy()).all():
        raise ValueError("Missing or non-finite prices require explicit data review.")
    if data.empty:
        raise ValueError("No usable price rows remain after normalization.")
    if (data <= 0).any().any():
        raise ValueError("Open and Close prices must be positive.")
    return data


def load_input_csv(path: str | Path) -> pd.DataFrame:
    return normalize_prices(pd.read_csv(path))


def fetch_yahoo(
    ticker: str,
    start: str,
    end: str,
    output_dir: str | Path,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Download adjusted OHLC data and preserve vendor response/provenance."""
    import yfinance as yf

    raw = yf.download(
        tickers=ticker,
        start=start,
        end=end,
        auto_adjust=True,
        actions=False,
        progress=False,
        threads=False,
        group_by="column",
    )
    if raw is None or raw.empty:
        raise RuntimeError(f"No Yahoo Finance data returned for {ticker}.")

    folder = Path(output_dir)
    folder.mkdir(parents=True, exist_ok=True)
    raw_path = folder / "vendor_raw.csv"
    raw.to_csv(raw_path)
    prices = normalize_prices(raw)
    normalized_path = folder / "normalized_prices.csv"
    prices.to_csv(normalized_path, date_format="%Y-%m-%d")
    provenance = {
        "source": "Yahoo Finance via yfinance",
        "ticker": ticker,
        "requested_start_inclusive": start,
        "requested_end_exclusive": end,
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "auto_adjust": True,
        "row_count": int(len(prices)),
        "first_date": prices.index.min().strftime("%Y-%m-%d"),
        "last_date": prices.index.max().strftime("%Y-%m-%d"),
        "vendor_raw_file": raw_path.name,
        "vendor_raw_sha256": sha256_file(raw_path),
        "normalized_file": normalized_path.name,
        "normalized_sha256": sha256_file(normalized_path),
        "software_versions": software_versions(),
    }
    with (folder / "provenance.json").open("w", encoding="utf-8") as handle:
        json.dump(provenance, handle, indent=2)
    return prices, provenance


def software_versions() -> dict[str, str | None]:
    result: dict[str, str | None] = {}
    for package in ("markov-reversibility-research", "numpy", "pandas", "scipy", "yfinance"):
        try:
            result[package] = version(package)
        except PackageNotFoundError:
            result[package] = None
    return result
