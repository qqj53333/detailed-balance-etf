"""Chronological walk-forward forecasting and long/cash backtest."""

from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np
import pandas as pd

from .metrics import (
    allocation_weight,
    calibration_table,
    forecast_metrics,
    strategy_metrics,
)
from .models import iid_probabilities, markov_matrix, reversible_matrix
from .states import STATE_NAMES, classify_returns, fit_thresholds

MODELS = ("iid", "markov", "reversible")
EVALUATION_SPLITS = ("development", "validation", "final_test")


def _split_for_target(
    target_date: pd.Timestamp,
    development_end: date,
    validation_end: date,
    final_end: date,
) -> str:
    day = target_date.date()
    if day <= development_end:
        return "development"
    if day <= validation_end:
        return "validation"
    if day <= final_end:
        return "final_test"
    return "outside_sample"


def run_walkforward(
    prices: pd.DataFrame,
    ticker: str,
    min_train_observations: int = 2520,
    alpha: float = 1.0,
    development_end: str = "2009-12-31",
    validation_end: str = "2014-12-31",
    final_end: str = "2025-12-31",
) -> pd.DataFrame:
    """Generate one forecast after each eligible close, in chronological order."""
    data = prices.copy().sort_index()
    if not isinstance(data.index, pd.DatetimeIndex):
        raise ValueError("Prices must have a DateTimeIndex.")
    required = {"Open", "Close"}
    if not required.issubset(data.columns):
        raise ValueError("Prices must contain Open and Close columns.")
    if min_train_observations < 2:
        raise ValueError("Minimum training history must be at least two sessions.")

    opens = data["Open"].to_numpy(dtype=float)
    closes = data["Close"].to_numpy(dtype=float)
    if np.any(~np.isfinite(opens)) or np.any(~np.isfinite(closes)):
        raise ValueError("Open and Close values must be finite.")
    if np.any(opens <= 0) or np.any(closes <= 0):
        raise ValueError("Open and Close values must be positive.")
    intraday_returns = closes / opens - 1.0
    dates = data.index
    dev_cutoff = date.fromisoformat(development_end)
    validation_cutoff = date.fromisoformat(validation_end)
    final_cutoff = date.fromisoformat(final_end)
    if not dev_cutoff < validation_cutoff <= final_cutoff:
        raise ValueError("Evaluation cutoffs must be in chronological order.")

    rows: list[dict[str, Any]] = []
    first_origin = min_train_observations - 1
    for origin in range(first_origin, len(data) - 1):
        training_returns = intraday_returns[: origin + 1]
        thresholds = fit_thresholds(training_returns)
        training_states = classify_returns(training_returns, thresholds)
        current_state = int(training_states[-1])

        iid = iid_probabilities(training_states, alpha=alpha)
        unrestricted = markov_matrix(training_states, alpha=alpha)
        (
            reversible,
            stationary,
            db_residual,
            optimizer_converged,
            optimizer_gradient_norm,
            optimizer_iterations,
        ) = reversible_matrix(
            training_states,
            alpha=alpha,
        )
        probabilities = {
            "iid": iid,
            "markov": unrestricted[current_state],
            "reversible": reversible[current_state],
        }

        target_return = float(intraday_returns[origin + 1])
        target_state = int(
            classify_returns(np.array([target_return]), thresholds)[0]
        )
        target_date = dates[origin + 1]
        row: dict[str, Any] = {
            "ticker": ticker,
            "signal_date": dates[origin].strftime("%Y-%m-%d"),
            "target_date": target_date.strftime("%Y-%m-%d"),
            "split": _split_for_target(
                target_date,
                dev_cutoff,
                validation_cutoff,
                final_cutoff,
            ),
            "current_state": STATE_NAMES[current_state],
            "target_state": target_state,
            "target_state_name": STATE_NAMES[target_state],
            "target_intraday_return": target_return,
            "lower_threshold": thresholds.lower,
            "upper_threshold": thresholds.upper,
            "reversible_detailed_balance_residual": db_residual,
            "reversible_optimizer_converged": optimizer_converged,
            "reversible_optimizer_gradient_inf_norm": optimizer_gradient_norm,
            "reversible_optimizer_iterations": optimizer_iterations,
            "reversible_stationary_down": float(stationary[0]),
            "reversible_stationary_neutral": float(stationary[1]),
            "reversible_stationary_up": float(stationary[2]),
        }
        for model in MODELS:
            p = probabilities[model]
            if not np.all(np.isfinite(p)) or not np.isclose(p.sum(), 1.0):
                raise RuntimeError(f"{model} produced an invalid forecast.")
            row[f"p_{model}_down"] = float(p[0])
            row[f"p_{model}_neutral"] = float(p[1])
            row[f"p_{model}_up"] = float(p[2])
            row[f"weight_{model}"] = float(allocation_weight(p.reshape(1, -1))[0])
        rows.append(row)

    if not rows:
        raise ValueError(
            "No forecasts were generated. Supply more data or reduce the "
            "minimum training history."
        )
    result = pd.DataFrame.from_records(rows)
    for model in MODELS:
        weight = result[f"weight_{model}"].to_numpy(dtype=float)
        result[f"gross_return_{model}"] = (
            weight * result["target_intraday_return"].to_numpy(dtype=float)
        )
        result[f"turnover_{model}"] = 2.0 * weight
    return result


def _probability_matrix(frame: pd.DataFrame, model: str) -> np.ndarray:
    return frame[
        [f"p_{model}_down", f"p_{model}_neutral", f"p_{model}_up"]
    ].to_numpy(dtype=float)


def build_metrics(
    forecasts: pd.DataFrame,
    cost_bps: tuple[float, ...] = (1.0, 5.0, 10.0, 25.0),
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Aggregate separate forecast and net portfolio metrics by split."""
    if not cost_bps or any(not np.isfinite(value) or value < 0 for value in cost_bps):
        raise ValueError("At least one finite, nonnegative one-way cost is required.")
    forecast_summary: dict[str, Any] = {}
    portfolio_summary: dict[str, Any] = {}
    calibration_frames: list[pd.DataFrame] = []
    evaluation = forecasts[forecasts["split"].isin(EVALUATION_SPLITS)]

    for split in EVALUATION_SPLITS:
        subset = evaluation[evaluation["split"] == split].copy()
        forecast_summary[split] = {}
        portfolio_summary[split] = {}
        if subset.empty:
            forecast_summary[split]["n_forecasts"] = 0
            portfolio_summary[split]["n_sessions"] = 0
            continue

        actual = subset["target_state"].to_numpy(dtype=np.int64)
        for model in MODELS:
            probabilities = _probability_matrix(subset, model)
            forecast_summary[split][model] = forecast_metrics(actual, probabilities)
            calibration = calibration_table(actual, probabilities)
            calibration.insert(0, "model", model)
            calibration.insert(0, "split", split)
            calibration_frames.append(calibration)

            portfolio_summary[split][model] = {}
            weight = subset[f"weight_{model}"].to_numpy(dtype=float)
            underlying = subset["target_intraday_return"].to_numpy(dtype=float)
            turnover = subset[f"turnover_{model}"].to_numpy(dtype=float)
            for bps in cost_bps:
                cost_rate = bps / 10_000.0
                daily_cost = turnover * cost_rate
                net = subset[f"gross_return_{model}"].to_numpy(dtype=float) - daily_cost
                portfolio_summary[split][model][f"{bps:g}_bps_per_side"] = {
                    **strategy_metrics(net, turnover, daily_cost),
                    "cost_bps_per_side": float(bps),
                }

        portfolio_summary[split]["benchmark_cash"] = {}
        portfolio_summary[split]["benchmark_intraday_long"] = {}
        underlying = subset["target_intraday_return"].to_numpy(dtype=float)
        for bps in cost_bps:
            cost_rate = bps / 10_000.0
            zero = np.zeros_like(underlying)
            long_turnover = np.full_like(underlying, 2.0)
            long_cost = long_turnover * cost_rate
            portfolio_summary[split]["benchmark_cash"][f"{bps:g}_bps_per_side"] = {
                **strategy_metrics(zero, zero, zero),
                "cost_bps_per_side": float(bps),
            }
            portfolio_summary[split]["benchmark_intraday_long"][
                f"{bps:g}_bps_per_side"
            ] = {
                **strategy_metrics(underlying - long_cost, long_turnover, long_cost),
                "cost_bps_per_side": float(bps),
            }

    calibration_frame = (
        pd.concat(calibration_frames, ignore_index=True)
        if calibration_frames
        else pd.DataFrame(
            columns=[
                "split",
                "model",
                "state",
                "bin",
                "bin_lower",
                "bin_upper",
                "count",
                "mean_forecast_probability",
                "observed_frequency",
            ]
        )
    )
    return {
        "forecast_metrics": forecast_summary,
        "portfolio_metrics": portfolio_summary,
        "cost_sensitivity_bps_per_side": [float(value) for value in cost_bps],
    }, calibration_frame
