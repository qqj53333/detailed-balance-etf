"""Paired moving-block bootstrap for saved chronological forecasts.

This resamples the observed forecast/outcome sequences; it does not refit models.
Intervals are conditional, approximate percentile intervals, not trading evidence.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .data import sha256_file, software_versions


def moving_block_indices(n: int, block_length: int,
                         rng: np.random.Generator) -> np.ndarray:
    """Sample overlapping non-circular blocks; truncate to n observations."""
    if block_length < 1 or n < 2 * block_length:
        raise ValueError("Require at least two blocks of observations.")
    starts = rng.integers(0, n - block_length + 1,
                         size=(n + block_length - 1) // block_length)
    return (starts[:, None] + np.arange(block_length)).ravel()[:n]


def _sharpe(returns: np.ndarray) -> float:
    std = np.std(returns, ddof=1)
    return float(np.sqrt(252) * np.mean(returns) / std) if std > 1e-15 else np.nan


def paired_intervals(a: np.ndarray, b: np.ndarray, block_length: int = 20,
                     replicates: int = 5000, seed: int = 20261113) -> dict:
    """Columns: log loss, Brier score, net return. Contrast is always A minus B."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if a.ndim != 2 or a.shape != b.shape or a.shape[1] != 3:
        raise ValueError("Paired data must have matching (n, 3) shapes.")
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError("Paired observations must be finite.")
    if replicates < 2:
        raise ValueError("At least two bootstrap replicates are required.")
    rng = np.random.default_rng(seed)
    statistics = ("log_loss_difference", "brier_difference",
                  "mean_daily_net_return_difference", "annualized_sharpe_difference")
    def differences(left, right):
        return np.r_[np.mean(left - right, axis=0),
                     _sharpe(left[:, 2]) - _sharpe(right[:, 2])]
    point = differences(a, b)
    bootstrap = np.empty((replicates, 4))
    for i in range(replicates):
        indices = moving_block_indices(len(a), block_length, rng)
        bootstrap[i] = differences(a[indices], b[indices])
    result = {}
    for j, name in enumerate(statistics):
        finite = np.isfinite(bootstrap[:, j])
        # Do not silently discard undefined Sharpe draws and present a full CI.
        interval = (np.quantile(bootstrap[:, j], [0.025, 0.975]).tolist()
                    if finite.all() and np.isfinite(point[j]) else None)
        result[name] = {
            "estimate": float(point[j]) if np.isfinite(point[j]) else None,
            "percentile_interval_95": interval,
            "valid_replicates": int(finite.sum()),
            "replicates": replicates,
            "preferred_direction": "negative" if j < 2 else "positive",
        }
    return result


def compare_forecasts(frame: pd.DataFrame, split: str = "validation",
                      cost_bps: float = 5, block_lengths=(20, 10, 60),
                      replicates: int = 5000, seed: int = 20261113) -> dict:
    """Compare models on identical dates within one named evaluation interval."""
    if not np.isfinite(cost_bps) or cost_bps < 0:
        raise ValueError("Cost must be finite and nonnegative.")
    selected = frame.loc[frame["split"] == split].copy()
    if selected.empty:
        raise ValueError(f"No forecasts in split {split}.")
    if selected["ticker"].nunique() != 1:
        raise ValueError("Compare exactly one asset at a time.")
    dates = pd.to_datetime(selected["target_date"], errors="raise")
    origins = pd.to_datetime(selected["signal_date"], errors="raise")
    if dates.duplicated().any() or not dates.is_monotonic_increasing:
        raise ValueError("Forecast dates must be unique and chronological.")
    if not (origins < dates).all():
        raise ValueError("Every signal must precede its target session.")
    labels = selected["target_state"].to_numpy()
    if not np.isin(labels, [0, 1, 2]).all():
        raise ValueError("Target states must be 0, 1, or 2.")
    labels = labels.astype(int)
    arrays = {}
    for model in ("iid", "markov", "reversible"):
        probs = selected[[f"p_{model}_{state}" for state in
                          ("down", "neutral", "up")]].to_numpy(dtype=float)
        if (not np.isfinite(probs).all() or (probs < 0).any()
                or not np.allclose(probs.sum(axis=1), 1, atol=1e-10, rtol=0)):
            raise ValueError("Invalid saved forecast probabilities.")
        loss = -np.log(np.clip(probs[np.arange(len(labels)), labels], 1e-15, 1))
        brier = np.sum((probs - np.eye(3)[labels]) ** 2, axis=1)
        net = (selected[f"gross_return_{model}"].to_numpy(dtype=float)
               - selected[f"turnover_{model}"].to_numpy(dtype=float) * cost_bps / 10000)
        arrays[model] = np.column_stack((loss, brier, net))
    comparisons = {}
    for left, right in (("reversible", "markov"), ("markov", "iid")):
        comparisons[f"{left}_minus_{right}"] = {}
        for length in block_lengths:
            comparisons[f"{left}_minus_{right}"][str(length)] = (
                paired_intervals(arrays[left], arrays[right], length, replicates, seed))
    return {
        "split": split, "ticker": selected["ticker"].iloc[0],
        "n_sessions": len(selected), "first_target": str(dates.min().date()),
        "last_target": str(dates.max().date()), "cost_bps_per_side": cost_bps,
        "method": "paired non-circular moving-block percentile bootstrap",
        "block_lengths": list(block_lengths), "primary_block_length": block_lengths[0],
        "replicates": replicates, "seed": seed, "comparisons": comparisons,
        "limitations": (
            "Conditional on saved forecasts; models and thresholds are not refitted. "
            "Approximation requires sufficient weak dependence/stability; regime changes "
            "can invalidate it. Intervals are pointwise, not multiplicity adjusted. "
            "Undefined Sharpe draws suppress the entire Sharpe interval. "
            "Do not interpret interval exclusion of zero as guaranteed profitability."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--forecasts", required=True)
    parser.add_argument("--split", choices=("development", "validation", "final_test"),
                        default="validation")
    parser.add_argument("--cost-bps", type=float, default=5)
    parser.add_argument("--block-lengths", type=int, nargs="+", default=[20, 10, 60])
    parser.add_argument("--replicates", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20261113)
    args = parser.parse_args()
    path = Path(args.forecasts)
    result = compare_forecasts(pd.read_csv(path), args.split, args.cost_bps,
                               args.block_lengths, args.replicates, args.seed)
    result["forecast_sha256"] = sha256_file(path)
    result["software_versions"] = software_versions()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = path.parent / f"inference_{args.split}_{stamp}.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False), encoding="utf-8")
    print(output.resolve())


if __name__ == "__main__":
    main()
