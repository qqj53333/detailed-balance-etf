"""Probability-forecast, calibration, and long/cash performance metrics."""

import numpy as np
import pandas as pd

from .states import N_STATES, STATE_NAMES


def _validated_probabilities(probabilities: np.ndarray) -> np.ndarray:
    values = np.asarray(probabilities, dtype=float)
    if values.ndim != 2 or values.shape[1] != N_STATES:
        raise ValueError("Probabilities must have shape (n_observations, 3).")
    if not np.all(np.isfinite(values)) or np.any(values < 0):
        raise ValueError("Probabilities must be finite and nonnegative.")
    row_sums = values.sum(axis=1, keepdims=True)
    if np.any(row_sums <= 0):
        raise ValueError("Every forecast row must have positive total mass.")
    return values / row_sums


def forecast_metrics(
    actual: np.ndarray,
    probabilities: np.ndarray,
) -> dict[str, float | int | None]:
    """Compute log loss, multiclass Brier score, and accuracy."""
    labels = np.asarray(actual, dtype=np.int64)
    probs = _validated_probabilities(probabilities)
    if labels.size != probs.shape[0] or labels.size == 0:
        raise ValueError("Actual states and probability rows must have equal nonzero length.")
    if np.any((labels < 0) | (labels >= N_STATES)):
        raise ValueError("Actual states must be integers 0, 1, or 2.")
    one_hot = np.eye(N_STATES, dtype=float)[labels]
    selected = np.clip(probs[np.arange(labels.size), labels], 1e-15, 1.0)
    return {
        "n_forecasts": int(labels.size),
        "log_loss": float(-np.mean(np.log(selected))),
        "brier_score": float(np.mean(np.sum((probs - one_hot) ** 2, axis=1))),
        "accuracy": float(np.mean(np.argmax(probs, axis=1) == labels)),
    }


def calibration_table(
    actual: np.ndarray,
    probabilities: np.ndarray,
    n_bins: int = 10,
) -> pd.DataFrame:
    """Create one-vs-rest reliability bins for each state."""
    labels = np.asarray(actual, dtype=np.int64)
    probs = _validated_probabilities(probabilities)
    if labels.size != probs.shape[0]:
        raise ValueError("Actual states and probability rows must have equal length.")
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    records: list[dict[str, float | int | str]] = []
    for state, name in enumerate(STATE_NAMES):
        forecast = probs[:, state]
        observed = (labels == state).astype(float)
        bins = np.digitize(forecast, edges[1:-1], right=False)
        for bin_index in range(n_bins):
            mask = bins == bin_index
            if not np.any(mask):
                continue
            records.append(
                {
                    "state": name,
                    "bin": bin_index,
                    "bin_lower": float(edges[bin_index]),
                    "bin_upper": float(edges[bin_index + 1]),
                    "count": int(mask.sum()),
                    "mean_forecast_probability": float(forecast[mask].mean()),
                    "observed_frequency": float(observed[mask].mean()),
                }
            )
    return pd.DataFrame.from_records(records)


def allocation_weight(probabilities: np.ndarray) -> np.ndarray:
    """Map state probabilities to a fixed 0-to-1 long/cash exposure."""
    probs = _validated_probabilities(probabilities)
    return np.clip(0.5 + 0.5 * (probs[:, 2] - probs[:, 0]), 0.0, 1.0)


def strategy_metrics(
    net_returns: np.ndarray,
    turnover: np.ndarray,
    transaction_costs: np.ndarray,
) -> dict[str, float | int | None]:
    """Summarize daily net returns and simulated trading activity."""
    returns = np.asarray(net_returns, dtype=float)
    turns = np.asarray(turnover, dtype=float)
    costs = np.asarray(transaction_costs, dtype=float)
    if returns.ndim != 1 or returns.size == 0:
        raise ValueError("At least one daily return is required.")
    if turns.size != returns.size or costs.size != returns.size:
        raise ValueError("Returns, turnover, and costs must have equal length.")
    wealth = np.cumprod(1.0 + returns)
    running_peak = np.maximum.accumulate(np.concatenate(([1.0], wealth)))[1:]
    drawdowns = wealth / running_peak - 1.0
    standard_deviation = float(np.std(returns, ddof=1)) if returns.size > 1 else 0.0
    sharpe = (
        float(np.sqrt(252.0) * np.mean(returns) / standard_deviation)
        if standard_deviation > 0
        else None
    )
    return {
        "n_sessions": int(returns.size),
        "cumulative_net_return": float(wealth[-1] - 1.0),
        "annualized_sharpe_zero_rf": sharpe,
        "maximum_drawdown": float(np.min(drawdowns)),
        "average_daily_turnover": float(np.mean(turns)),
        "annualized_turnover": float(252.0 * np.mean(turns)),
        "total_transaction_cost_return": float(np.sum(costs)),
        "mean_daily_net_return": float(np.mean(returns)),
    }
