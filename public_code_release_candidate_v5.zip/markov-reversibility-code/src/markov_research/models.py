"""IID, unrestricted Markov, and detailed-balance-constrained estimators."""

import numpy as np
from scipy.optimize import minimize
from scipy.special import softmax

from .states import N_STATES


def transition_counts(states: np.ndarray) -> np.ndarray:
    """Count adjacent transitions in an integer state sequence."""
    values = np.asarray(states, dtype=np.int64)
    if values.ndim != 1 or values.size < 2:
        raise ValueError("At least two one-dimensional state labels are required.")
    if np.any((values < 0) | (values >= N_STATES)):
        raise ValueError("State labels must be integers 0, 1, or 2.")
    counts = np.zeros((N_STATES, N_STATES), dtype=float)
    np.add.at(counts, (values[:-1], values[1:]), 1.0)
    return counts


def iid_probabilities(states: np.ndarray, alpha: float = 1.0) -> np.ndarray:
    """Return smoothed unconditional destination-state probabilities."""
    values = np.asarray(states, dtype=np.int64)
    if values.ndim != 1 or values.size < 2:
        raise ValueError("At least two one-dimensional state labels are required.")
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("Smoothing alpha must be positive.")
    counts = np.bincount(values[1:], minlength=N_STATES).astype(float)
    return (counts + alpha) / (counts.sum() + alpha * N_STATES)


def markov_matrix(states: np.ndarray, alpha: float = 1.0) -> np.ndarray:
    """Estimate an unrestricted transition matrix with add-alpha smoothing."""
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("Smoothing alpha must be positive.")
    counts = transition_counts(states)
    smoothed = counts + alpha
    return smoothed / smoothed.sum(axis=1, keepdims=True)


def reversible_matrix(
    states: np.ndarray,
    alpha: float = 1.0,
    maxiter: int = 500,
) -> tuple[np.ndarray, np.ndarray, float, bool, float, int]:
    """Fit a reversible transition matrix by smoothed maximum likelihood.

    A symmetric stationary-flow matrix X is represented by six nonnegative
    masses: three diagonal terms and three off-diagonal pairs. The softmax
    parameterization makes total matrix mass one. Off-diagonal pair mass is
    split equally across X[i, j] and X[j, i]. Then pi is the row sum of X and
    P[i, j] = X[i, j] / pi[i], which enforces detailed balance by construction.
    """
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("Smoothing alpha must be positive.")
    counts = transition_counts(states)
    smoothed_counts = counts + alpha
    pairs = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))

    initial_masses = np.empty(len(pairs), dtype=float)
    for k, (i, j) in enumerate(pairs):
        initial_masses[k] = (
            smoothed_counts[i, i]
            if i == j
            else smoothed_counts[i, j] + smoothed_counts[j, i]
        )
    initial_logits = np.log(initial_masses / initial_masses.sum())
    initial = initial_logits[:-1] - initial_logits[-1]

    def masses_from_parameters(parameters: np.ndarray) -> np.ndarray:
        # Fix the last logit at zero to remove softmax's additive non-identifiability.
        return softmax(np.concatenate((parameters, np.zeros(1, dtype=float))))

    def flow_from_parameters(parameters: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        masses = masses_from_parameters(parameters)
        flow = np.zeros((N_STATES, N_STATES), dtype=float)
        for mass, (i, j) in zip(masses, pairs):
            if i == j:
                flow[i, i] = mass
            else:
                flow[i, j] = mass / 2.0
                flow[j, i] = mass / 2.0
        stationary = flow.sum(axis=1)
        matrix = flow / stationary[:, None]
        return flow, matrix

    def negative_log_likelihood(parameters: np.ndarray) -> float:
        masses = masses_from_parameters(parameters)
        flow, _ = flow_from_parameters(parameters)
        stationary = flow.sum(axis=1)
        grouped_counts = np.empty(len(pairs), dtype=float)
        for k, (i, j) in enumerate(pairs):
            grouped_counts[k] = (
                smoothed_counts[i, i]
                if i == j
                else smoothed_counts[i, j] + smoothed_counts[j, i]
            )
        row_counts = smoothed_counts.sum(axis=1)
        log_flow_term = float(np.sum(grouped_counts * np.log(masses)))
        log_stationary_term = float(np.sum(row_counts * np.log(stationary)))
        off_diagonal_constant = float(
            sum(
                grouped_counts[k] * np.log(2.0)
                for k, (i, j) in enumerate(pairs)
                if i != j
            )
        )
        return -log_flow_term + log_stationary_term + off_diagonal_constant

    def gradient(parameters: np.ndarray) -> np.ndarray:
        masses = masses_from_parameters(parameters)
        flow, _ = flow_from_parameters(parameters)
        stationary = flow.sum(axis=1)
        grouped_counts = np.empty(len(pairs), dtype=float)
        for k, (i, j) in enumerate(pairs):
            grouped_counts[k] = (
                smoothed_counts[i, i]
                if i == j
                else smoothed_counts[i, j] + smoothed_counts[j, i]
            )
        row_counts = smoothed_counts.sum(axis=1)
        gradient_masses = -grouped_counts / masses
        for k, (i, j) in enumerate(pairs):
            if i == j:
                gradient_masses[k] += row_counts[i] / stationary[i]
            else:
                gradient_masses[k] += 0.5 * (
                    row_counts[i] / stationary[i]
                    + row_counts[j] / stationary[j]
                )
        full_gradient = masses * (
            gradient_masses - float(np.dot(masses, gradient_masses))
        )
        return full_gradient[:-1]

    result = minimize(
        negative_log_likelihood,
        initial,
        method="BFGS",
        jac=gradient,
        options={"maxiter": maxiter, "gtol": 1e-8},
    )
    if not np.isfinite(result.fun) or not np.all(np.isfinite(result.x)):
        raise RuntimeError("Reversible estimator returned non-finite parameters.")
    gradient_norm = float(np.linalg.norm(gradient(result.x), ord=np.inf))
    converged = bool(result.success or gradient_norm <= 1e-6)
    if not converged:
        raise RuntimeError(
            "Reversible estimator did not converge: "
            f"{result.message}; iterations={result.nit}"
        )

    flow, matrix = flow_from_parameters(result.x)
    stationary = flow.sum(axis=1)
    detailed_balance_flow = stationary[:, None] * matrix
    residual = float(np.max(np.abs(detailed_balance_flow - detailed_balance_flow.T)))
    return matrix, stationary, residual, converged, gradient_norm, int(result.nit)
