"""Training-only threshold estimation and three-state return labels."""

from dataclasses import dataclass

import numpy as np

STATE_NAMES = ("Down", "Neutral", "Up")
N_STATES = len(STATE_NAMES)


@dataclass(frozen=True)
class StateThresholds:
    lower: float
    upper: float


def fit_thresholds(returns: np.ndarray) -> StateThresholds:
    """Estimate empirical terciles from the array supplied by the caller.

    The walk-forward caller must pass only observations known at its forecast
    origin. This function intentionally has no access to dates or future data.
    """
    values = np.asarray(returns, dtype=float)
    values = values[np.isfinite(values)]
    if values.size < 2:
        raise ValueError("At least two finite training returns are required.")
    lower, upper = np.quantile(values, [1.0 / 3.0, 2.0 / 3.0])
    if not np.isfinite(lower) or not np.isfinite(upper):
        raise ValueError("Could not estimate finite state thresholds.")
    return StateThresholds(float(lower), float(upper))


def classify_returns(returns: np.ndarray, thresholds: StateThresholds) -> np.ndarray:
    """Map returns to Down=0, Neutral=1, Up=2 using frozen cut points."""
    values = np.asarray(returns, dtype=float)
    if not np.all(np.isfinite(values)):
        raise ValueError("Returns must be finite before state classification.")
    return np.where(
        values <= thresholds.lower,
        0,
        np.where(values <= thresholds.upper, 1, 2),
    ).astype(np.int64)
