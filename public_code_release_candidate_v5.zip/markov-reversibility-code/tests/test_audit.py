import sys
from pathlib import Path
import unittest
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from markov_research.audit import audit_prices


class CoverageAudit(unittest.TestCase):
    def setUp(self):
        # Explicit fixture includes a weekend/holiday gap; no calendar inference.
        self.sessions = pd.to_datetime(["2005-01-14", "2005-01-18", "2005-01-19"])
        self.prices = pd.DataFrame({"Open": [100., 101., 102.],
                                    "Close": [101., 102., 101.]}, index=self.sessions)

    def test_complete_sessions_allow_nontrading_gaps(self):
        self.assertTrue(audit_prices(self.prices, self.sessions)["passed_session_coverage"])

    def test_missing_edges_and_internal_session_are_reported(self):
        for index in range(3):
            report = audit_prices(self.prices.drop(self.sessions[index]), self.sessions)
            self.assertFalse(report["passed_session_coverage"])
            self.assertEqual(report["missing_sessions"],
                             [str(self.sessions[index].date())])

    def test_weekend_record_is_rejected(self):
        extra = self.prices.copy()
        extra.loc[pd.Timestamp("2005-01-15")] = [100., 100.]
        report = audit_prices(extra.sort_index(), self.sessions)
        self.assertEqual(report["unexpected_sessions"], ["2005-01-15"])
        self.assertFalse(report["passed_session_coverage"])
