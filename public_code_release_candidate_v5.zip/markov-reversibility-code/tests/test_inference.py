"""Statistical implementation checks using synthetic series only."""
import sys
from pathlib import Path
import unittest
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from markov_research.inference import moving_block_indices, paired_intervals


class InferenceContract(unittest.TestCase):
    def test_blocks_preserve_internal_order_and_length(self):
        indices = moving_block_indices(103, 20, np.random.default_rng(1))
        self.assertEqual(len(indices), 103)
        self.assertTrue(((indices >= 0) & (indices < 103)).all())
        for i in range(0, 103, 20):
            np.testing.assert_array_equal(np.diff(indices[i:i+20]), 1)

    def test_identical_models_have_zero_paired_differences(self):
        a = np.random.default_rng(2).normal(size=(140, 3))
        result = paired_intervals(a, a, replicates=100)
        for value in result.values():
            self.assertEqual(value["estimate"], 0)
            self.assertEqual(value["percentile_interval_95"], [0, 0])

    def test_known_constant_score_difference_and_reproducibility(self):
        a = np.random.default_rng(3).normal(size=(140, 3))
        b = a.copy()
        b[:, 0] += 0.5
        first = paired_intervals(a, b, replicates=100)
        self.assertEqual(first, paired_intervals(a, b, replicates=100))
        np.testing.assert_allclose(
            first["log_loss_difference"]["percentile_interval_95"], [-0.5, -0.5])

    def test_short_samples_rejected(self):
        with self.assertRaises(ValueError):
            moving_block_indices(20, 20, np.random.default_rng(1))

    def test_undefined_sharpe_is_not_silently_reported(self):
        a = np.zeros((100, 3))
        result = paired_intervals(a, a, replicates=100)
        self.assertIsNone(result["annualized_sharpe_difference"]["estimate"])
        self.assertIsNone(result["annualized_sharpe_difference"]["percentile_interval_95"])
        self.assertEqual(result["annualized_sharpe_difference"]["valid_replicates"], 0)


if __name__ == "__main__":
    unittest.main()
