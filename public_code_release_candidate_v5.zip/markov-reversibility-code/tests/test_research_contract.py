"""Offline, synthetic checks of research invariants; no market findings."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from markov_research.data import normalize_prices
from markov_research.experiment import run_walkforward
from markov_research.metrics import forecast_metrics, strategy_metrics
from markov_research.models import reversible_matrix, markov_matrix


def synthetic_prices(n=80):
    rng = np.random.default_rng(20261113)
    return pd.DataFrame(
        {"Open": np.full(n, 100.0),
         "Close": 100 * (1 + rng.normal(0, 0.01, n))},
        index=pd.bdate_range("2005-01-03", periods=n, name="Date"))


class ResearchContract(unittest.TestCase):
    def test_reversible_cycle_known_solution(self):
        states = np.r_[np.tile([0, 1, 2], 100), 0]
        matrix, pi, residual, converged, _, _ = reversible_matrix(states)
        expected = np.full((3, 3), 51 / 103)
        np.fill_diagonal(expected, 1 / 103)
        np.testing.assert_allclose(matrix, expected, atol=1e-7)
        np.testing.assert_allclose(pi, np.full(3, 1/3), atol=1e-7)
        self.assertTrue(converged)
        self.assertLess(residual, 1e-12)
        self.assertGreater(np.max(np.abs(markov_matrix(states) - matrix)), 0.4)

    def test_reversible_sparse_and_random_histories(self):
        rng = np.random.default_rng(42)
        for states in [np.zeros(5000, dtype=int),
                       np.array([0, 2]),
                       rng.integers(0, 3, 3000)]:
            matrix, pi, residual, converged, _, _ = reversible_matrix(states)
            np.testing.assert_allclose(matrix.sum(axis=1), 1, atol=1e-12)
            np.testing.assert_allclose(pi @ matrix, pi, atol=1e-12)
            self.assertTrue((matrix > 0).all())
            self.assertTrue(converged)
            self.assertLess(residual, 1e-12)

    def test_future_prices_cannot_change_existing_decisions(self):
        original = synthetic_prices()
        altered = original.copy()
        altered.iloc[76:, altered.columns.get_loc("Close")] *= 1.25
        before = run_walkforward(original, "SYNTHETIC", 30)
        after = run_walkforward(altered, "SYNTHETIC", 30)
        cutoff = original.index[76].strftime("%Y-%m-%d")
        cols = [c for c in before if c.startswith(("p_", "weight_"))]
        cols += ["lower_threshold", "upper_threshold"]
        pd.testing.assert_frame_equal(
            before.loc[before.target_date <= cutoff, cols],
            after.loc[after.target_date <= cutoff, cols])
        self.assertTrue((pd.to_datetime(before.signal_date)
                         < pd.to_datetime(before.target_date)).all())

    def test_uniform_probability_scores(self):
        scores = forecast_metrics(np.array([0, 1, 2]), np.full((3, 3), 1/3))
        self.assertAlmostEqual(scores["log_loss"], np.log(3))
        self.assertAlmostEqual(scores["brier_score"], 2/3)

    def test_drawdown_includes_initial_capital(self):
        scores = strategy_metrics(np.array([-0.1, 0.1]), np.zeros(2), np.zeros(2))
        self.assertAlmostEqual(scores["maximum_drawdown"], -0.1)
        self.assertAlmostEqual(scores["cumulative_net_return"], -0.01)

    def test_reject_missing_prices_and_duplicate_dates(self):
        prices = synthetic_prices(5)
        missing = prices.copy()
        missing.iloc[2, 0] = np.nan
        with self.assertRaises(ValueError):
            normalize_prices(missing)
        with self.assertRaises(ValueError):
            normalize_prices(pd.concat([prices, prices.iloc[:1]]))
        with self.assertRaises(ValueError):
            normalize_prices(prices.reset_index(drop=True))

    def test_cli_phase_costs_and_artifacts(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            prices = synthetic_prices()
            input_path = folder / "synthetic.csv"
            prices.to_csv(input_path)
            end = prices.index[49].strftime("%Y-%m-%d")
            environment = dict(os.environ)
            environment["PYTHONPATH"] = str(ROOT / "src")
            process = subprocess.run(
                [sys.executable, "-m", "markov_research.cli",
                 "--ticker", "SYNTHETIC", "--input-csv", str(input_path),
                 "--output", str(folder / "runs"), "--min-train", "30",
                 "--development-end", "2005-01-31", "--validation-end", end],
                env=environment, text=True, capture_output=True)
            self.assertEqual(process.returncode, 0, process.stderr)
            run = next((folder / "runs").iterdir())
            summary = json.loads((run / "summary.json").read_text())
            forecasts = pd.read_csv(run / "forecasts.csv")
            self.assertEqual(summary["phase"], "validation")
            self.assertLessEqual(forecasts.target_date.max(), end)
            self.assertEqual(len(forecasts), 20)
            for model in ["iid", "markov", "reversible"]:
                expected_cost = 2 * forecasts[f"weight_{model}"] * 5 / 10000
                np.testing.assert_allclose(forecasts[f"cost_{model}_5bps"], expected_cost)
                np.testing.assert_allclose(
                    forecasts[f"net_return_{model}_5bps"],
                    forecasts[f"gross_return_{model}"] - expected_cost)
            self.assertTrue((run / "provenance.json").exists())
            self.assertTrue((run / "calibration.csv").exists())
            inference = subprocess.run(
                [sys.executable, "-m", "markov_research.inference",
                 "--forecasts", str(run / "forecasts.csv"), "--split", "validation",
                 "--block-lengths", "5", "--replicates", "100"],
                env=environment, text=True, capture_output=True)
            self.assertEqual(inference.returncode, 0, inference.stderr)
            report = json.loads(next(run.glob("inference_*.json")).read_text())
            self.assertEqual(report["n_sessions"], len(forecasts))
            self.assertEqual(report["block_lengths"], [5])
            self.assertIn("reversible_minus_markov", report["comparisons"])


if __name__ == "__main__":
    unittest.main()
