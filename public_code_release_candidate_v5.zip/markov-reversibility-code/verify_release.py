"""Verify the frozen model and local release identity."""
from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((root/"frozen_fingerprints.json").read_text())
for path,expected in f["source_sha256"].items():
    assert sha(root/path)==expected, path
if (root/"release_manifest.json").exists():
    for path,expected in json.loads((root/"release_manifest.json").read_text()).items():
        assert sha(root/path)==expected, path
print("Frozen source and release hashes match.")
